dw_moments <- function(q, beta) {
  lambda <- (-log(q))^(-1 / beta)
  c(mean = lambda * gamma(1 + 1 / beta) - 0.5,
    var  = lambda^2 * (gamma(1 + 2 / beta) - gamma(1 + 1 / beta)^2))
}

solve_dw_params <- function(q0, beta0, pct_mean_change, pct_var_change) {
  m0 <- dw_moments(q0, beta0)
  mean_t <- unname(m0["mean"] * (1 + pct_mean_change / 100))
  var_t  <- unname(m0["var"]  * (1 + pct_var_change  / 100))
  
  obj <- function(par) {
    m <- dw_moments(plogis(par[1]), exp(par[2]))
    ((m["mean"] - mean_t) / mean_t)^2 + ((m["var"] - var_t) / var_t)^2
  }
  
  fit <- optim(c(qlogis(q0), log(beta0)), obj,
               method = "Nelder-Mead", control = list(reltol = 1e-14, maxit = 5000))
  
  q1 <- plogis(fit$par[1]); beta1 <- exp(fit$par[2])
  m1 <- dw_moments(q1, beta1)
  
  list(q0 = q0, beta0 = beta0, mean0 = unname(m0["mean"]), var0 = unname(m0["var"]),
       q1 = q1, beta1 = beta1, mean1 = unname(m1["mean"]), var1 = unname(m1["var"]))
}