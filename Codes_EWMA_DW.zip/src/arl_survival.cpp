#include <Rcpp.h>
#include <vector>
#include <cmath>
#include <string>

using namespace Rcpp;

// arl_survival_cpp (v2 -- cadeia de Markov absorvente discretizada)
// ------------------------------------------------------------------
// A versao anterior tentava rastrear cada valor EXATO de Z, combinando
// com todos os valores de Y a cada passo. Como Z e uma combinacao
// convexa de valores reais, o numero de estados distintos cresce sem
// limite, o que e inviavel computacionalmente (e o corte forcado pelo
// numero maximo de estados descartava massa de probabilidade real,
// nao so cauda irrelevante -- por isso os ARL saiam errados).
//
// Esta versao usa a abordagem classica de cadeia de Markov absorvente
// para EWMA (Lucas & Saccucci, 1990, citado no plano): discretiza a
// regiao de sobrevivencia em m subintervalos de largura fixa, cada
// um representado pelo seu ponto medio. Constroi UMA UNICA matriz de
// transicao A (m x m), sub-estocastica (linhas somam < 1; a massa
// perdida e a probabilidade de absorcao/sinal). O espaco de estados
// tem tamanho FIXO m, independente de quantos passos rodam -- e o
// mesmo espirito do gera_v1 (ProgA.R), que ja usa uma matriz de
// transicao de tamanho fixo (k*n) e potencia de matriz.
//
// direcao = "inferior": regiao de sobrevivencia = [L, max(Y)]   (LCL, sinal se Z < L)
// direcao = "superior": regiao de sobrevivencia = [min(Y), L]   (UCL, sinal se Z > L)
//
// m: numero de subintervalos usados para discretizar a regiao de
//    sobrevivencia. Quanto maior m, mais preciso (e mais lento).
//    Recomendado: comecar com m = 300-500 e checar convergencia
//    aumentando m (o ARL deve estabilizar) -- mesmo principio de
//    verificacao de convergencia usado nos outros metodos de MCA.
//
// [[Rcpp::export]]
List arl_survival_cpp(double f,
                       NumericVector Y,
                       NumericVector PY,
                       double L,
                       std::string direcao = "inferior",
                       int m = 500,
                       int max_steps = 1000,
                       double eps_stop = 1e-11) {

  bool inferior = (direcao == "inferior");
  if (!inferior && direcao != "superior") {
    stop("direcao deve ser 'inferior' ou 'superior'.");
  }
  if (m < 2) {
    stop("m deve ser >= 2.");
  }

  int n_y = Y.size();

  double z_min = Y[0], z_max = Y[0];
  for (int i = 0; i < n_y; i++) {
    if (Y[i] < z_min) z_min = Y[i];
    if (Y[i] > z_max) z_max = Y[i];
  }

  // Regiao de sobrevivencia [a, b)
  double a, b;
  if (inferior) {
    a = L;
    b = z_max;
  } else {
    a = z_min;
    b = L;
  }

  if (b <= a) {
    stop("L invalido para essa direcao: intervalo de sobrevivencia vazio ou negativo.");
  }

  double h = (b - a) / m;

  // Convencao usual de SPC: sinaliza com desigualdade ESTRITA no
  // limite (Z > UCL ou Z < LCL); o ponto exatamente sobre o limite
  // ainda e' considerado sob controle.
  //   inferior (LCL): sobrevive se z >= L   (sinal se z <  L)
  //   superior (UCL): sobrevive se z <= L   (sinal se z >  L)
  auto sobrevive = [&](double z) {
    return inferior ? (z >= L) : (z <= L);
  };

  auto bin_index = [&](double z) -> int {
    int k = (int) std::floor((z - a) / h);
    if (k < 0) k = 0;
    if (k > m - 1) k = m - 1;
    return k;
  };

  // ---- Distribuicao inicial p^(1): Z_1 = Y_1 (valor exato, sem discretizar) ----
  std::vector<double> p(m, 0.0);
  for (int j = 0; j < n_y; j++) {
    double y = Y[j];
    if (sobrevive(y)) {
      p[bin_index(y)] += PY[j];
    }
  }

  std::vector<double> S; // S[t-1] = S(t)
  {
    double s1 = 0.0;
    for (double pv : p) s1 += pv;
    S.push_back(s1);
  }

  // ---- Matriz de transicao A (m x m), construida UMA VEZ ----
  // A[i][k] = P(Z_t cai no bin k | Z_{t-1} = ponto medio do bin i, sobrevive)
  std::vector<std::vector<double>> A(m, std::vector<double>(m, 0.0));
  for (int i = 0; i < m; i++) {
    double mu_i = a + (i + 0.5) * h;
    for (int j = 0; j < n_y; j++) {
      double new_z = f * Y[j] + (1.0 - f) * mu_i;
      if (sobrevive(new_z)) {
        A[i][bin_index(new_z)] += PY[j];
      }
    }
  }

  // ---- Propagacao p^(t) = p^(t-1) %*% A ----
  int t = 1;
  while (t < max_steps && S.back() >= eps_stop) {
    t++;
    std::vector<double> p_new(m, 0.0);
    for (int i = 0; i < m; i++) {
      double pi = p[i];
      if (pi <= 0.0) continue;
      const std::vector<double>& Ai = A[i];
      for (int k = 0; k < m; k++) {
        if (Ai[k] > 0.0) p_new[k] += pi * Ai[k];
      }
    }
    p.swap(p_new);

    double st = 0.0;
    for (double pv : p) st += pv;
    S.push_back(st);
  }

  double ARL = 1.0;
  for (double sv : S) ARL += sv;

  bool convergiu = (!S.empty()) && (S.back() < eps_stop);

  return List::create(
    Named("L")         = L,
    Named("direcao")   = direcao,
    Named("m")         = m,
    Named("S")         = wrap(S),
    Named("ARL")       = ARL,
    Named("passos")    = t,
    Named("convergiu") = convergiu,
    Named("massa_residual") = S.empty() ? NA_REAL : S.back()
  );
}
