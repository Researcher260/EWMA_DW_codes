## ------------------------------------------------------------------
## busca_ARL_exato.R
##
## Substitui a logica de ProgB.R + trecho de ARL em Rodar.R.
## Nao usa 1/alpha em nenhum momento: tanto a busca do limite de
## controle quanto o ARL1 final sao lidos via soma de sobrevivencia
## (arl_survival_cpp), conforme Secao 3.1 do plano.
##
## v2: arl_survival_cpp agora usa cadeia de Markov absorvente
## discretizada (m subintervalos, ao estilo Lucas & Saccucci 1990),
## em vez de rastrear cada valor exato de Z -- a abordagem anterior
## nao escalava (espaco de estados sem limite fixo).
## ------------------------------------------------------------------

Rcpp::sourceCpp(file.path("src", "arl_survival.cpp"))

#' Ajusta as distribuicoes de Y sob H0 e H1 para o mesmo suporte.
#'
#' CORRECAO IMPORTANTE (v2): a versao anterior filtrava v0 por VALOR
#' (a[a >= tol]), o que pode remover elementos de QUALQUER posicao do
#' vetor (nao so do final) -- por exemplo, para n grande, a
#' distribuicao do contador apos n passos costuma ter massa quase
#' nula logo nos primeiros valores de Y, entao esses eram removidos
#' do INICIO. O codigo entao fazia Y <- 0:(n_estados-1), assumindo
#' que o suporte remanescente comecava em Y=0 -- o que desloca toda
#' a escala de Y quando elementos iniciais sao removidos.
#'
#' Alem disso, v1 (H1) era truncado apenas por COMPRIMENTO
#' (b[1:n_estados]), sem aplicar o mesmo filtro por valor -- entao,
#' mesmo com v0 == v1 (mesma distribuicao em H0 e H1), PY_0 e PY_1
#' podiam acabar representando pedacos DIFERENTES do suporte,
#' causando ARL0 e ARL1 muito diferentes mesmo sem mudanca real de
#' distribuicao (bug que apareceu no teste com n=30).
#'
#' Esta versao filtra os DOIS vetores pelos MESMOS indices (decididos
#' a partir de v0), preservando o alinhamento entre PY_0, PY_1 e Y.
prepara_PY <- function(v0, v1, tol = 1e-11) {

  a <- v0
  b <- v1

  idx_manter <- which(a >= tol)
  if (length(idx_manter) <= 1) {
    stop("Vetor 'v0' invalido apos truncamento.")
  }

  # Valores de Y correspondentes as posicoes de a (v0 e v1 sao
  # indexados a partir de Y = 0, como em gera_v1/ProgA.R)
  Y_original <- 0:(length(a) - 1)
  Y <- Y_original[idx_manter]

  a_ajustado <- a[idx_manter]
  a_ajustado[length(a_ajustado)] <- 1 - sum(a_ajustado[-length(a_ajustado)])

  # b (H1) usa os MESMOS indices de a (H0) -- preserva alinhamento de Y.
  # Se b for mais curto que o maior indice necessario, completa com zero.
  if (max(idx_manter) > length(b)) {
    b <- c(b, rep(0, max(idx_manter) - length(b)))
  }
  b_ajustado <- b[idx_manter]

  massa_b_capturada <- sum(b_ajustado)
  if (massa_b_capturada < 1 - 1e-4) {
    warning(sprintf(
      "prepara_PY: apenas %.6f da massa de probabilidade de v1 (H1) esta dentro do suporte truncado de v0 (H0). Isso indica que H1 tem massa relevante fora da regiao onde H0 tem massa nao-desprezivel -- o truncamento pode estar descartando parte importante da distribuicao de H1. Considere revisar tol ou os parametros de H1.",
      massa_b_capturada
    ))
  }
  if (sum(b_ajustado[-length(b_ajustado)]) > 1 + 1e-8) {
    stop("Soma dos elementos de 'v1' excede 1.")
  }
  b_ajustado[length(b_ajustado)] <- 1 - sum(b_ajustado[-length(b_ajustado)])

  list(
    Y    = Y,
    PY_0 = a_ajustado,
    PY_1 = b_ajustado
  )
}

#' ARL exato (sobrevivencia, cadeia de Markov discretizada) para um L
#' fixo e uma distribuicao PY.
#'
#' m: numero de subintervalos usados para discretizar a regiao de
#'   sobrevivencia. Comece com 300-500; se quiser confirmar
#'   convergencia, rode de novo com m maior (ex: 1000) e compare o
#'   ARL -- deve estabilizar (mesmo principio de checagem usado nos
#'   outros metodos de MCA do projeto).
arl_exato <- function(f, Y, PY, L, direcao = "inferior",
                       m = 500, max_steps = 1000, eps_stop = 1e-11) {

  res <- arl_survival_cpp(
    f = f, Y = Y, PY = PY, L = L, direcao = direcao,
    m = m, max_steps = max_steps, eps_stop = eps_stop
  )

  if (!res$convergiu) {
    warning(sprintf(
      "arl_exato: nao convergiu em %d passos (massa residual = %.3e) para L = %.6f, direcao = %s. Aumente max_steps.",
      res$passos, res$massa_residual, L, direcao
    ))
  }

  res
}

#' Busca DISCRETA do limite de controle: avalia ARL0 em cada valor
#' possivel de L dentre o suporte de Y (0, 1, 2, ..., max(Y)) e
#' escolhe o mais proximo do alvo.
#'
#' Uso: quando lambda = 1 (ou proximo disso), Z_t = Y_t e' discreto,
#' entao ARL0(L) e' uma funcao em DEGRAUS -- so muda de valor quando
#' L cruza um inteiro do suporte de Y, e fica constante entre dois
#' inteiros consecutivos. Nesse caso pode nao existir NENHUM L (nem
#' fracionario) que de ARL0 = target_ARL0 exatamente; o uniroot
#' (que assume continuidade) pode reportar um L arbitrario perto de
#' um salto, sem garantir que seja o degrau mais proximo do alvo.
#' Esta funcao evita isso avaliando todos os candidatos possiveis
#' diretamente, sem assumir continuidade.
busca_L_discreto <- function(f, Y, PY_0,
                              target_ARL0 = 200,
                              theta = 0.01,
                              direcao = "inferior",
                              m = 500,
                              max_steps = 1000,
                              eps_stop = 1e-11) {

  candidatos <- sort(unique(Y))

  # Alguns candidatos extremos deixam a regiao de sobrevivencia vazia
  # (ex: L = max(Y) para direcao "inferior", ou L = min(Y) para
  # "superior") -- nao sao limites de controle validos. Em vez de
  # filtrar com base em suposicoes sobre a direcao, avalia todos e
  # descarta (NA) os que derem erro, mantendo o restante.
  arl0_candidatos <- vapply(candidatos, function(L) {
    tryCatch(
      arl_exato(f = f, Y = Y, PY = PY_0, L = L, direcao = direcao,
                m = m, max_steps = max_steps, eps_stop = eps_stop)$ARL,
      error = function(e) NA_real_
    )
  }, numeric(1))

  if (all(is.na(arl0_candidatos))) {
    stop("busca_L_discreto: nenhum candidato de L produziu uma regiao de sobrevivencia valida.")
  }

  idx_melhor <- which.min(abs(arl0_candidatos - target_ARL0))
  L_final    <- candidatos[idx_melhor]
  ARL0_final <- arl0_candidatos[idx_melhor]

  dentro_tol <- abs(ARL0_final - target_ARL0) <= theta * target_ARL0

  if (!dentro_tol) {
    warning(sprintf(
      "busca_L_discreto: nao existe L cujo ARL0 fique dentro de %.0f%% de %d. Melhor disponivel: L = %s, ARL0 = %.3f (degrau discreto -- solucao exata nao existe nesse caso).",
      theta * 100, target_ARL0, format(L_final), ARL0_final
    ))
  }

  list(
    L                  = L_final,
    ARL0               = ARL0_final,
    direcao            = direcao,
    dentro_tolerancia  = dentro_tol,
    solucao_exata_existe = dentro_tol,
    convergiu          = TRUE,  # busca discreta nao depende de convergencia iterativa
    candidatos_L       = candidatos,
    candidatos_ARL0    = arl0_candidatos
  )
}

#' Busca o limite de controle L tal que o ARL0 EXATO (via sobrevivencia)
#' bate no alvo, dentro da tolerancia theta -- substitui a Eq. (21)
#' do manuscrito, que usava 1/alpha como criterio de aceitacao.
#'
#' direcao = "inferior": procura LCL (sinal quando Z <= LCL)
#' direcao = "superior": procura UCL (sinal quando Z >= UCL)
#'
#' modo = "auto": usa busca discreta automaticamente quando f == 1
#'   (Z_t = Y_t, discreto, ARL0(L) em degraus -- ver busca_L_discreto);
#'   caso contrario usa uniroot continuo. modo = "continuo" ou
#'   "discreto" forcam um dos dois metodos.
busca_L_exato <- function(f, Y, PY_0,
                           target_ARL0 = 200,
                           theta = 0.01,
                           direcao = "inferior",
                           intervalo = NULL,
                           m = 500,
                           max_steps = 1000,
                           eps_stop = 1e-11,
                           tol_uniroot = 1e-6,
                           modo = c("auto", "continuo", "discreto")) {

  modo <- match.arg(modo)
  usar_discreto <- (modo == "discreto") || (modo == "auto" && f >= 1 - 1e-9)

  if (usar_discreto) {
    return(busca_L_discreto(
      f = f, Y = Y, PY_0 = PY_0, target_ARL0 = target_ARL0, theta = theta,
      direcao = direcao, m = m, max_steps = max_steps, eps_stop = eps_stop
    ))
  }

  media_Y <- sum(Y * PY_0)

  if (is.null(intervalo)) {
    intervalo <- if (direcao == "inferior") {
      c(min(Y) + 1e-6, media_Y)
    } else {
      c(media_Y, max(Y) - 1e-6)
    }
  }

  obj <- function(L) {
    arl_exato(f = f, Y = Y, PY = PY_0, L = L, direcao = direcao,
              m = m, max_steps = max_steps, eps_stop = eps_stop)$ARL - target_ARL0
  }

  f_lo <- obj(intervalo[1])
  f_hi <- obj(intervalo[2])

  # ARL0 deve ser monotono em L: decrescente se "inferior" (LCL mais
  # perto da media -> absorcao mais provavel -> ARL0 menor);
  # crescente se "superior" (mesma logica espelhada).
  if (sign(f_lo) == sign(f_hi)) {
    stop(sprintf(
      "Intervalo inicial [%.6f, %.6f] nao contem raiz: ARL0(%.6f) = %.3f, ARL0(%.6f) = %.3f. Ajuste 'intervalo'.",
      intervalo[1], intervalo[2], intervalo[1], f_lo + target_ARL0,
      intervalo[2], f_hi + target_ARL0
    ))
  }

  raiz <- uniroot(obj, interval = intervalo, tol = tol_uniroot)
  L_final <- raiz$root

  resultado_final <- arl_exato(f = f, Y = Y, PY = PY_0, L = L_final,
                                direcao = direcao, m = m,
                                max_steps = max_steps, eps_stop = eps_stop)

  dentro_tol <- abs(resultado_final$ARL - target_ARL0) <= theta * target_ARL0

  list(
    L               = L_final,
    ARL0            = resultado_final$ARL,
    direcao         = direcao,
    dentro_tolerancia = dentro_tol,
    passos          = resultado_final$passos,
    convergiu       = resultado_final$convergiu,
    S               = resultado_final$S
  )
}

#' Pipeline completo: recebe v0, v1 (saida de gera_v1), acha o L exato
#' sob H0 e le o ARL1 exato no mesmo L sob H1. Substitui quantile_z().
calcula_ARL_exato <- function(f, v0, v1, n,
                               target_ARL0 = 200,
                               theta = 0.01,
                               direcao = "inferior",
                               tol = 1e-11,
                               m = 500,
                               max_steps = 1000,
                               eps_stop = 1e-11,
                               modo = c("auto", "continuo", "discreto")) {

  modo <- match.arg(modo)
  dados <- prepara_PY(v0, v1, tol = tol)

  busca <- busca_L_exato(
    f = f, Y = dados$Y, PY_0 = dados$PY_0,
    target_ARL0 = target_ARL0, theta = theta, direcao = direcao,
    m = m, max_steps = max_steps, eps_stop = eps_stop, modo = modo
  )

  leitura_h1 <- arl_exato(
    f = f, Y = dados$Y, PY = dados$PY_1, L = busca$L, direcao = direcao,
    m = m, max_steps = max_steps, eps_stop = eps_stop
  )

  list(
    n       = n,
    lambda  = f,
    direcao = direcao,
    L       = busca$L,          # limite na escala de Z (igual a z_h0 do codigo antigo)
    LCL_ou_UCL_normalizado = busca$L / n,  # mesma normalizacao usada em Rodar.R (LCL <- z_h0/n)
    ARL0    = busca$ARL0,
    ARL1    = leitura_h1$ARL,
    dentro_tolerancia = busca$dentro_tolerancia,
    convergiu_h0 = busca$convergiu,
    convergiu_h1 = leitura_h1$convergiu
  )
}
