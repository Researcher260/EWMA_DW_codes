gera_v1 <- function(n, q, beta){
  
  # Regra para definição de k
  if (n >= 30) {
    k <- 30
  } else {
    k <- qdweibull(0.9999, q, beta, zero = TRUE)
  }
  
  x <- 0:(k*n - 1)
  
  prob <- pmap_dbl(
    .l = list(
      x = x,
      q = list(q),
      beta = list(beta),
      zero = list(TRUE)
    ),
    .f = ddweibull
  )
  
  gera_matriz <- function(prob){
    
    prob_last <- 1 - sum(prob)
    
    k_n <- length(prob) + 1
    
    prob_matrix <- matrix(0, nrow = k_n, ncol = k_n)
    
    prob_matrix[1, ] <- c(prob, prob_last)
    
    for(i in 2:k_n){
      prob_matrix[i, ] <- c(
        0,
        prob_matrix[i-1, 1:(k_n-2)],
        sum(prob_matrix[i-1, -(1:(k_n-2))])
      )
    }
    
    prob_matrix
  }
  
  Q <- gera_matriz(prob)
  
  Q_exp_n <- Q %^% n
  
  vetor_b <- c(1, rep(0, length(prob)))
  
  v1 <- as.numeric(t(vetor_b) %*% Q_exp_n)
  
  ## Nome do arquivo
  nome_arquivo <- sprintf(
    "v1_n%d_q%.5f_beta%.3f.RData",
    n, q, beta
  )
  
  ## Salva no diretório de trabalho atual
  #save(v1, file = nome_arquivo)
  
  return(v1)
}