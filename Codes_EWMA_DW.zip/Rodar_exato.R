library(Rcpp)
library(tidyverse)
library(pracma)
library(DiscreteWeibull)
library(expm)
library(writexl)

clear()
tic()

setwd(dirname(normalizePath(sys.frame(1)$ofile)))
source("ProgA.R")            # gera_v1 -- inalterado
source("busca_ARL_exato.R")  # substitui ProgB.R / quantile_z

N <- c(2,3,5,10,30,50,100)
L_lambda <- c(0.1,0.25,0.75,1)
q0 <- 0.904182
beta0 <- 1.5
PM=c(0,5,10,15,20)
PV=c(0,5,15,20)
target_ARL0 <- 200
theta <- 0.01
direcao <- "superior"   # sinal quando Z >= L -> busca UCL

# Numero de linhas = todas as combinacoes 
n_casos <- length(N) * length(L_lambda)*length(PM)*length(PV)
Resultado <- matrix(0, n_casos, 15)

cont <- 1
for (i in seq_along(N)) {
  for (j in seq_along(L_lambda)) {
    for (k in seq_along(PM)) {
      for (l in seq_along(PV)) {
        print(cont)
        lambda <- L_lambda[j]
        n <- N[i]
        pm=PM[k]
        pv=PV[l]
        source("mv.R")
        resA <- solve_dw_params(q0, beta0, pm, pv)
        q1=resA$q1
        beta1=resA$beta1
        
        
        # Gerar distribuicoes (inalterado)
        v0 <- gera_v1(n, q0, beta0)
        v1 <- gera_v1(n, q1, beta1)
        
        # ARL exato via sobrevivencia (substitui quantile_z + 1/alpha)
        res <- calcula_ARL_exato(
          f = lambda, v0 = v0, v1 = v1, n = n,
          target_ARL0 = target_ARL0, theta = theta, direcao = direcao
        )
        
        if (!res$dentro_tolerancia) {
          warning(sprintf(
            "n=%d, lambda=%.2f: ARL0 exato = %.3f fora da tolerancia de %.0f%% em torno de %d.",
            n, lambda, res$ARL0, theta * 100, target_ARL0
          ))
        }
        
        Resultado[cont, 1] <- n
        Resultado[cont, 2] <- lambda
        Resultado[cont, 3] <- res$ARL0
        Resultado[cont, 4] <- res$ARL1
        Resultado[cont, 5] <- q0
        Resultado[cont, 6] <- beta0
        Resultado[cont, 7] <- q1
        Resultado[cont, 8] <- beta1
        Resultado[cont, 9] <- res$LCL_ou_UCL_normalizado*n
        Resultado[cont, 10] <- resA$mean0
        Resultado[cont, 11] <- resA$var0
        Resultado[cont, 12] <- resA$mean1
        Resultado[cont, 13] <- resA$var1
        Resultado[cont, 14] <- pm
        Resultado[cont, 15] <- pv
        
        cont <- cont + 1
      }
    }
  }
}

Result <- data.frame(Resultado)
colnames(Result) <- c(
  "n", "lambda", "Arl0_exato", "Arl1_exato",
  "q0", "beta0", "q1", "beta1", "Limite", "mu0", "var0", "mu1","var1",
  "pm","pv"
)

writexl::write_xlsx(Result, "Result_exato.xlsx")

toc()
